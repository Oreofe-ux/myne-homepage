import {useState} from "react"; 
import {RxHamburgerMenu} from "react-icons/rx";
import {HiXMark} from "react-icons/hi2";
import "./Navbar.css";
import myneLogo from "../../assets/myne_logo_white_3.png";

function Navbar(){
const [isMenuOpen, setIsMenuOpen] = useState(false);

return(
        <nav className="navbar">
            <div className="nav-container">

               <img className="logo" alt="MYNE logo" src={myneLogo}/>

               <button className="menu-btn" aria-label="Toggle navigation menu"
               onClick={() => setIsMenuOpen(!isMenuOpen)}
               aria-expanded={isMenuOpen}>
                    {isMenuOpen ? <HiXMark/> : <RxHamburgerMenu/>}
                </button>

                {isMenuOpen && (<div className ="mobile-menu">
                    <ul className="mobile-nav-list">
                        <li><a href="#" onClick={()=>setIsMenuOpen(false)}>Home</a></li>
                        <li><a href="#" onClick={()=>setIsMenuOpen(false)}>Why MYNE</a></li>
                        <li><a href="#" onClick={()=>setIsMenuOpen(false)}>Our Services</a></li>
                        <li><a href="#">Contact</a></li>
                    </ul>

                    <button className="main-cta-button" onClick={()=>setIsMenuOpen(false)}>Book a Demo</button>
                </div>)}
            </div>
        </nav>
    )
}

export default Navbar